//! Represents all possible errors in the application

use thiserror::Error;
#[derive(Error, Debug)]
pub enum AppError {
    #[error("Validation failed")]
    Validation(),

    #[error("Login failed")]
    Login(),

    #[error("Register failed")]
    Register(),

    #[error("Post failed")]
    Post()
}
