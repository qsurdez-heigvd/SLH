use anyhow::{bail, Context, Result};
use std::num::NonZeroU32;
use unicode_normalization::UnicodeNormalization;
use ammonia::{clean, is_html};
use regex::Regex;
use once_cell::sync::Lazy;
use image::ImageFormat;


/// Constants for validation limits
pub const MAX_USERNAME_LENGTH: usize = 64;
pub const MAX_PASSWORD_LENGTH: usize = 128;
pub const MIN_PASSWORD_LENGTH: usize = 8;
pub const MAX_CONTENT_LENGTH: usize = 2_000;
pub const MAX_SHORT_CONTENT_LENGTH: usize = 250;

/*
/// A secure wrapper for validated user input that cannot be constructed
/// without passing validation checks. This enforces validation at the type level.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ValidatedInput<T> {
    inner: T,
    validation_type: ValidationType,
}
*/

/// Represents all possible types of validation that our system can perform.
/// This helps us track what kind of validation was applied to any given input.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ValidationType {
    // Text-based validations
    Username,
    Password,
    Email,
    LongContent,
    ShortContent,
    Html,

    // File-based validations
    ImageFile(FileType),
    DocumentFile(FileType),
    GenericFile(FileType),
}

/// Represents the specific type of file being validated.
/// This allows us to enforce different rules for different file types.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FileType {
    Jpeg,
    Png,
    Pdf,
    // We can add more file types as needed
}

impl FileType {
    /// Returns the allowed file extensions for each file type.
    /// This is crucial for validating uploaded files to prevent
    /// security issues with malicious file extensions.
    pub fn allowed_extensions(&self) -> &'static [&'static str] {
        match self {
            FileType::Jpeg => &["jpg", "jpeg"],
            FileType::Png => &["png"],
            FileType::Pdf => &["pdf"],
        }
    }

    /// Returns the expected MIME type for each file type.
    /// This helps ensure file content matches its claimed type.
    pub fn image_type(&self) -> &'static str {
        match self {
            FileType::Jpeg => "image/jpeg",
            FileType::Png => "image/png",
            FileType::Pdf => "application/pdf",
        }
    }
}

/// Implement Display to enable string formatting of FileType
impl std::fmt::Display for FileType {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.image_type())
    }
}

/// A secure wrapper that holds validated input of any supported type.
/// This ensures that any data that's been validated maintains its validated status.
#[derive(Debug, Clone)]
pub enum ValidatedInput {
    Text(String),
    File(FileContent),
}

impl ValidatedInput {
    /// Returns a reference to the inner validated content.
    /// This method provides convenient access to the validated data
    /// while maintaining the validation guarantees.
    pub fn as_inner(&self) -> &str {
        match self {
            ValidatedInput::Text(text) => text.as_str(),
            ValidatedInput::File(file) => &file.filename,
        }
    }
}

/// Implement AsRef<str> for ValidatedInput to allow for ergonomic
/// string references. This makes ValidatedInput work seamlessly
/// with functions that accept string references.
impl AsRef<str> for ValidatedInput {
    fn as_ref(&self) -> &str {
        self.as_inner()
    }
}

/// Implement Display to allow easy string formatting
impl std::fmt::Display for ValidatedInput {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.as_inner())
    }
}

/// FileContent needs its own AsRef implementation to maintain
/// consistent behavior across the validation system
impl AsRef<str> for FileContent {
    fn as_ref(&self) -> &str {
        &self.filename
    }
}
/// Represents file content along with its metadata
#[derive(Debug, Clone)]
pub struct FileContent {
    content: Vec<u8>,
    filename: String,
    mime_type: Option<String>,
    file_type: FileType,
}

/// A builder-pattern validator that can handle both text and file inputs
pub struct InputValidator<T> {
    input: T,
    // Common validation settings
    max_length: Option<usize>,
    min_length: Option<usize>,
    allow_whitespace: bool,
    normalize_unicode: bool,

    // Text-specific settings
    allow_html: bool,
    sanitize_html: bool,

    // File-specific settings
    max_file_size: Option<usize>,
    allowed_file_types: Vec<FileType>,
    max_image_dimensions: Option<(u32, u32)>,

    // Custom validation functions
    custom_validators: Vec<Box<dyn Fn(&T) -> Result<()>>>,
}

impl InputValidator<String> {
    /// Creates a new validator for text input
    pub fn for_text(input: String) -> Self {
        Self {
            input,
            max_length: Some(256),
            min_length: Some(2),
            allow_whitespace: true,
            normalize_unicode: false,
            allow_html: false,
            sanitize_html: false,
            max_file_size: None,
            allowed_file_types: vec![],
            max_image_dimensions: None,
            custom_validators: Vec::new(),
        }
    }

    /// Performs text validation according to configured rules
    pub fn validate(self, validation_type: ValidationType) -> Result<ValidatedInput> {
        // First perform common text validations
        let processed_text = self.validate_text_common()?;

        // Then perform specific validations based on type
        match validation_type {
            ValidationType::Email => {
                validators::validate_email(&processed_text)?;
            }
            ValidationType::Username => {
                validators::validate_username(&processed_text)?;
            }
            ValidationType::Password => {
                validators::validate_password_strength(&processed_text)?;
            }
            ValidationType::Html => {
                if !self.allow_html && is_html(&processed_text) {
                    bail!("HTML content is not allowed");
                }
                if self.sanitize_html {
                    return Ok(ValidatedInput::Text(clean(&processed_text)));
                }
            }
            _ => bail!("Invalid validation type for text input"),
        }

        Ok(ValidatedInput::Text(processed_text))
    }

    /// Common validation logic for text inputs
    fn validate_text_common(&self) -> Result<String> {
        let input_str = self.input.as_str();

        if input_str.is_empty() {
            bail!("Input cannot be empty");
        }

        if let Some(max) = self.max_length {
            if input_str.len() > max {
                bail!("Input exceeds maximum length of {}", max);
            }
        }

        if let Some(min) = self.min_length {
            if input_str.len() < min {
                bail!("Input is shorter than minimum length of {}", min);
            }
        }

        // Normalize Unicode if requested
        let processed = if self.normalize_unicode {
            input_str.nfkc().collect::<String>()
        } else {
            input_str.to_string()
        };

        Ok(processed)
    }
}

impl InputValidator<FileContent> {
    /// Creates a new validator for file input
    pub fn for_file(content: Vec<u8>, filename: String, file_type: FileType) -> Self {
        Self {
            input: FileContent {
                content,
                filename,
                mime_type: None,
                file_type,
            },
            max_length: None,
            min_length: None,
            allow_whitespace: false,
            normalize_unicode: false,
            allow_html: false,
            sanitize_html: false,
            max_file_size: None,
            allowed_file_types: Vec::new(),
            max_image_dimensions: None,
            custom_validators: vec![],
        }
    }

    /// Sets maximum allowed file size
    pub fn max_file_size(mut self, size: usize) -> Self {
        self.max_file_size = Some(size);
        self
    }

    /// Sets allowed image dimensions
    pub fn max_image_dimensions(mut self, width: u32, height: u32) -> Self {
        self.max_image_dimensions = Some((width, height));
        self
    }

    /// Performs file validation according to configured rules
    pub fn validate(self, validation_type: ValidationType) -> Result<ValidatedInput> {
        let file = self.input;

        // Validate file extension
        file_validators::validate_extension(&file.filename, &[file.file_type])?;

        // Validate file size if specified
        if let Some(max_size) = self.max_file_size {
            file_validators::validate_file_size(&file.content, max_size)?;
        }

        // Perform type-specific validations
        match file.file_type {
            FileType::Jpeg => {
                file_validators::validate_jpeg_integrity(&file.content)?;

                if let Some((max_width, max_height)) = self.max_image_dimensions {
                    file_validators::validate_image_dimensions(
                        &file.content,
                        max_width,
                        max_height,
                    )?;
                }
            }
            // Add other file type validations as needed
            _ => {}
        }

        Ok(ValidatedInput::File(file))
    }
}

/// Common validation functions that can be reused across the application
pub mod validators {
    use super::*;
    use regex::Regex;

    /// Validates email addresses according to HTML5 specification
    pub fn validate_email(email: &str) -> Result<()> {
        static EMAIL_REGEX: Lazy<Regex> = Lazy::new(|| {
            Regex::new(r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$").unwrap()
        });

        if !EMAIL_REGEX.is_match(email) {
            bail!("Invalid email format");
        }
        Ok(())
    }

    /// Validates username format allowing only safe characters
    pub fn validate_username(username: &str) -> Result<()> {
        static USERNAME_REGEX: Lazy<Regex> = Lazy::new(|| {
            Regex::new(r"^[a-zA-Z0-9][a-zA-Z0-9_-]*$").unwrap()
        });

        if !USERNAME_REGEX.is_match(username) {
            bail!("Username must contain only letters, numbers, underscores, and hyphens, and start with a letter or number");
        }
        Ok(())
    }

    /// Validates password strength using multiple criteria
    pub fn validate_password_strength(password: &str) -> Result<()> {
        let has_uppercase = password.chars().any(|c| c.is_uppercase());
        let has_lowercase = password.chars().any(|c| c.is_lowercase());
        let has_number = password.chars().any(|c| c.is_numeric());
        let has_special = password.chars().any(|c| !c.is_alphanumeric());

        if !has_uppercase || !has_lowercase || !has_number || !has_special {
            bail!("Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character");
        }
        Ok(())
    }


}

/// File validation module containing specific validation functions
pub mod file_validators {
    use std::path::Path;
    use anyhow::bail;
    use image::GenericImageView;
    use super::*;

    /// Validates a file's extension
    pub fn validate_extension(filename: &str, allowed_types: &[FileType]) -> Result<()> {
        let extension = Path::new(filename)
            .extension()
            .and_then(|ext| ext.to_str())
            .map(|s| s.to_lowercase());

        let extension = extension.ok_or_else(|| {
            anyhow::anyhow!("File must have an extension")
        })?;

        // Check if the extension matches any of the allowed types
        if !allowed_types.iter().any(|ft| {
            ft.allowed_extensions()
                .iter()
                .any(|&allowed| allowed == extension)
        }) {
            // Create a list of allowed extensions by collecting them into a Vec<String>
            // This converts the &&str into owned String values that can be joined
            let allowed_extensions: Vec<String> = allowed_types
                .iter()
                .flat_map(|ft| ft.allowed_extensions().iter())
                .map(|&ext| ext.to_string())  // Convert &str to String
                .collect();

            bail!("Invalid file extension. Allowed extensions: {}",
                  allowed_extensions.join(", "));
        }

        Ok(())
    }

    /// Validates image dimensions
    pub fn validate_image_dimensions(
        content: &[u8],
        max_width: u32,
        max_height: u32,
    ) -> Result<()> {
        let img = image::load_from_memory(content)
            .context("Failed to load image")?;

        let dimensions = img.dimensions();
        if dimensions.0 > max_width || dimensions.1 > max_height {
            bail!(
                "Image dimensions ({} x {}) exceed maximum allowed ({} x {})",
                dimensions.0,
                dimensions.1,
                max_width,
                max_height
            );
        }

        Ok(())
    }


    /// Validates JPEG image integrity
    pub fn validate_jpeg_integrity(content: &[u8]) -> Result<()> {
        // Try to decode the image to verify its integrity
        match image::load_from_memory_with_format(content, ImageFormat::Jpeg) {
            Ok(_) => Ok(()),
            Err(e) => bail!("Invalid JPEG image: {}", e),
        }
    }

    /// Validates image file size
    pub fn validate_file_size(content: &[u8], max_size: usize) -> Result<()> {
        if content.len() > max_size {
            bail!(
                "File size {} bytes exceeds maximum allowed size of {} bytes",
                content.len(),
                max_size
            );
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // Helper function to create test strings of specific lengths
    fn create_string_of_length(length: usize, char: char) -> String {
        char.to_string().repeat(length)
    }

    mod text_validation {
        use super::*;

        #[test]
        /// Tests validation of valid usernames with different allowed characters
        fn test_valid_usernames() {
            let valid_usernames = vec![
                "user123",
                "john_doe",
                "test-user",
                "a1",  // Minimum length with both letter and number
                "user123_test-name",  // Mix of all allowed characters
            ];

            for username in valid_usernames {
                let result = InputValidator::for_text(username.to_string())
                    .validate(ValidationType::Username);
                assert!(result.is_ok(), "Username should be valid: {}", username);
            }
        }
    }
}
